"""Exhaustive finite positive CPU16-bit neighbor check; no whole-program proof."""
import argparse
import datetime
import hashlib
import json
import math
import platform
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
sys.path.insert(0, str(ROOT))
import torch
import dlrs.scheduler
import dlrs.utils


def hashes():
    result = {}
    for module in (dlrs.scheduler, dlrs.utils):
        path = Path(module.__file__).resolve()
        assert path.parent == ROOT / "dlrs", "Unexpected imported source"
        result[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def decode(bits, fraction_bits, exponent_bits, bias):
    fraction = bits & ((1 << fraction_bits) - 1)
    exponent = bits >> fraction_bits
    if exponent == (1 << exponent_bits) - 1:
        return math.inf
    if exponent == 0:
        return math.ldexp(float(fraction), 1 - bias - fraction_bits)
    return math.ldexp(float((1 << fraction_bits) + fraction), exponent - bias - fraction_bits)


parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--native", action="store_true")
args = parser.parse_args()
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
before = hashes()
results = []
for dtype, fraction_bits, exponent_bits, bias, greatest in (
    (torch.float16, 10, 5, 15, 0x7bff),
    (torch.bfloat16, 7, 8, 127, 0x7f7f),
):
    patterns = torch.arange(1, greatest + 1, dtype=torch.int16)
    values = patterns.view(dtype)
    original = patterns.clone()
    for increase in (False, True):
        direction = 1 if increase else -1
        actual = dlrs.scheduler._positive_lr_neighbor(values, increase)
        expected = torch.tensor([decode(bits + direction, fraction_bits, exponent_bits, bias)
                                 for bits in range(1, greatest + 1)], dtype=dtype)
        assert torch.equal(actual.view(torch.int16), expected.view(torch.int16))
        if args.native:
            native = torch.nextafter(values, torch.full_like(values, math.inf if increase else -math.inf))
            assert torch.equal(actual.view(torch.int16), native.view(torch.int16))
        assert torch.equal(patterns, original)
        assert actual.dtype == dtype and actual.device == values.device
        assert actual.data_ptr() != values.data_ptr()
        if increase:
            assert math.isinf(float(actual[-1]))
        else:
            assert float(actual[0]) == 0.0 and math.copysign(1.0, float(actual[0])) == 1.0
        results.append({"dtype": str(dtype), "direction": "up" if increase else "down",
                        "positive_finite_inputs": greatest, "ieee_reference_bitwise_match": True,
                        "torch_nextafter_bitwise_match": True if args.native else None})
after = hashes()
assert before == after
report = {"scope": "Exhaustive helper check for finite positive CPU float16/bfloat16 values; not whole-implementation proof.",
          "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "python": platform.python_version(), "torch": str(torch.__version__),
          "platform": platform.platform(), "torch_threads": torch.get_num_threads(),
          "torch_interop_threads": torch.get_num_interop_threads(),
          "source_before_sha256": before, "source_after_sha256": after,
          "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "total_direction_checks": sum(row["positive_finite_inputs"] for row in results),
          "minimum_to_positive_zero_and_maximum_to_infinity_checked": True,
          "inputs_unchanged_and_outputs_independent": True,
          "reference": "Decode adjacent positive IEEE bit patterns by signless exponent/significand powers of two, then cast exact binary64 values to target dtype.",
          "results": results}
with args.output.open("x", encoding="utf-8") as stream:
    json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write("\n")
print(str(args.output), report["total_direction_checks"], "all matched")
