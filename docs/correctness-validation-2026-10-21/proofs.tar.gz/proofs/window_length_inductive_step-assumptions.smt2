(set-option :timeout 5000)
(set-logic QF_LIA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun patience () Int)
(declare-fun length () Int)
(declare-fun next_length () Int)
(assert
 (>= patience 0))
(assert
 (>= length 0))
(assert
 (let ((?x169 (+ patience 2)))
 (<= length ?x169)))
(assert
 (let ((?x177 (+ length 1)))
(let ((?x169 (+ patience 2)))
(= next_length (ite (> ?x177 ?x169) ?x169 ?x177)))))
(check-sat)
