(set-option :timeout 5000)
(set-logic QF_LIA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun patience () Int)
(declare-fun length () Int)
(assert
 (>= patience 0))
(assert
 (= length 0))
(check-sat)
