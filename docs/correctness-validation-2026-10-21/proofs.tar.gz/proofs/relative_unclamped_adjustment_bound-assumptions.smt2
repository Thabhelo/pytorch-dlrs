(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun delta_d () Real)
(declare-fun delta_o () Real)
(declare-fun delta_i () Real)
(declare-fun rate () Real)
(declare-fun granularity () Real)
(declare-fun lower () Real)
(declare-fun n () Real)
(declare-fun slope () Real)
(assert
 (> delta_d 0.0))
(assert
 (> delta_o 0.0))
(assert
 (> delta_i 0.0))
(assert
 (> rate 0.0))
(assert
 (> granularity 0.0))
(assert
 (> lower 0.0))
(assert
 (>= n 2.0))
(assert
 (>= slope (- n)))
(assert
 (<= slope n))
(assert
 (<= granularity rate))
(assert
 (let ((?x119 (* 10.0 granularity)))
(< rate ?x119)))
(check-sat)
