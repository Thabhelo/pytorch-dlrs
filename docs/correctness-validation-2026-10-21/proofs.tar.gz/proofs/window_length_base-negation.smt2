(set-option :timeout 5000)
(set-logic QF_LIA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun patience () Int)
(declare-fun length () Int)
(assert
 (>= patience 0))
(assert
 (= length 0))
(assert
 (let ((?x169 (+ patience 2)))
(let (($x174 (<= length ?x169)))
(let (($x173 (>= length 0)))
(let (($x175 (and $x173 $x174)))
(not $x175))))))
(check-sat)
