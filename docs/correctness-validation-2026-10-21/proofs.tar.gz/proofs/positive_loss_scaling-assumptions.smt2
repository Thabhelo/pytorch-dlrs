(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun first () Real)
(declare-fun last () Real)
(declare-fun total () Real)
(declare-fun n () Real)
(declare-fun slope () Real)
(declare-fun positive_factor () Real)
(declare-fun scaled_slope () Real)
(assert
 (>= first 0.0))
(assert
 (>= last 0.0))
(assert
 (> total 0.0))
(assert
 (>= total (+ first last)))
(assert
 (>= n 2.0))
(assert
 (= (* slope total) (* n (- last first))))
(assert
 (> positive_factor 0.0))
(assert
 (= (* scaled_slope (* positive_factor total)) (* n (- (* positive_factor last) (* positive_factor first)))))
(check-sat)
