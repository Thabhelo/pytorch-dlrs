(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun lower () Real)
(declare-fun upper () Real)
(declare-fun arbitrary () Real)
(assert
 (> lower 0.0))
(assert
 (> upper lower))
(assert
 (let ((?x103 (ite (< arbitrary lower) lower arbitrary)))
(let ((?x105 (ite (> ?x103 upper) upper ?x103)))
(let ((?x107 (ite (< ?x105 lower) lower ?x105)))
(let (($x110 (= (ite (> ?x107 upper) upper ?x107) ?x105)))
(not $x110))))))
(check-sat)
