(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun delta_d () Real)
(declare-fun delta_o () Real)
(declare-fun delta_i () Real)
(declare-fun rate () Real)
(declare-fun granularity () Real)
(declare-fun lower () Real)
(declare-fun slope () Real)
(assert
 (> delta_d 0.0))
(assert
 (> delta_o 0.0))
(assert
 (> delta_i 0.0))
(assert
 (> rate 0.0))
(assert
 (> granularity 0.0))
(assert
 (> lower 0.0))
(assert
 (> slope 0.0))
(assert
 (let (($x62 (>= slope 0.0)))
(let ((?x63 (ite $x62 delta_o delta_i)))
(let (($x61 (> slope 1.0)))
(let ((?x64 (ite $x61 delta_d ?x63)))
(let ((?x87 (- rate (* (* granularity ?x64) slope))))
(let (($x95 (< ?x87 rate)))
(not $x95))))))))
(check-sat)
