(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun delta_d () Real)
(declare-fun delta_o () Real)
(declare-fun delta_i () Real)
(declare-fun slope () Real)
(assert
 (> delta_d 0.0))
(assert
 (> delta_o 0.0))
(assert
 (> delta_i 0.0))
(assert
 (>= slope 0.0))
(assert
 (<= slope 1.0))
(assert
 (let (($x62 (>= slope 0.0)))
(let ((?x63 (ite $x62 delta_o delta_i)))
(let (($x61 (> slope 1.0)))
(let ((?x64 (ite $x61 delta_d ?x63)))
(let (($x68 (> ?x64 0.0)))
(let (($x71 (and (= ?x64 delta_o) $x68)))
(not $x71))))))))
(check-sat)
