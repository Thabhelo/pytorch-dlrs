(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun lower () Real)
(declare-fun upper () Real)
(assert
 (> lower 0.0))
(assert
 (> upper lower))
(check-sat)
