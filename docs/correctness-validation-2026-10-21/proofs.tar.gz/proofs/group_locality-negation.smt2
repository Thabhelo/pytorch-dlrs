(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun delta_d () Real)
(declare-fun delta_o () Real)
(declare-fun delta_i () Real)
(declare-fun rate () Real)
(declare-fun granularity () Real)
(declare-fun lower () Real)
(declare-fun upper () Real)
(declare-fun other_rate () Real)
(declare-fun other_rate_changed () Real)
(declare-fun other_granularity () Real)
(declare-fun other_granularity_changed () Real)
(declare-fun slope () Real)
(declare-fun next_a () Real)
(declare-fun next_b () Real)
(declare-fun next_a_again () Real)
(declare-fun next_b_again () Real)
(assert
 (> delta_d 0.0))
(assert
 (> delta_o 0.0))
(assert
 (> delta_i 0.0))
(assert
 (> rate 0.0))
(assert
 (> granularity 0.0))
(assert
 (> lower 0.0))
(assert
 (> upper lower))
(assert
 (>= other_rate 0.0))
(assert
 (>= other_rate_changed 0.0))
(assert
 (> other_granularity 0.0))
(assert
 (> other_granularity_changed 0.0))
(assert
 (let (($x62 (>= slope 0.0)))
 (let ((?x63 (ite $x62 delta_o delta_i)))
 (let (($x61 (> slope 1.0)))
 (let ((?x64 (ite $x61 delta_d ?x63)))
 (let ((?x87 (- rate (* (* granularity ?x64) slope))))
 (let ((?x90 (ite (< ?x87 lower) lower ?x87)))
 (let (($x88 (= rate 0.0)))
 (let ((?x93 (ite $x88 0.0 (ite (> ?x90 upper) upper ?x90))))
 (= next_a ?x93))))))))))
(assert
 (let (($x62 (>= slope 0.0)))
 (let ((?x63 (ite $x62 delta_o delta_i)))
 (let (($x61 (> slope 1.0)))
 (let ((?x64 (ite $x61 delta_d ?x63)))
 (let ((?x146 (- other_rate (* (* other_granularity ?x64) slope))))
 (let ((?x148 (ite (< ?x146 lower) lower ?x146)))
 (let (($x143 (= other_rate 0.0)))
 (= next_b (ite $x143 0.0 (ite (> ?x148 upper) upper ?x148)))))))))))
(assert
 (let (($x62 (>= slope 0.0)))
 (let ((?x63 (ite $x62 delta_o delta_i)))
 (let (($x61 (> slope 1.0)))
 (let ((?x64 (ite $x61 delta_d ?x63)))
 (let ((?x87 (- rate (* (* granularity ?x64) slope))))
 (let ((?x90 (ite (< ?x87 lower) lower ?x87)))
 (let (($x88 (= rate 0.0)))
 (let ((?x93 (ite $x88 0.0 (ite (> ?x90 upper) upper ?x90))))
 (= next_a_again ?x93))))))))))
(assert
 (let (($x62 (>= slope 0.0)))
 (let ((?x63 (ite $x62 delta_o delta_i)))
 (let (($x61 (> slope 1.0)))
 (let ((?x64 (ite $x61 delta_d ?x63)))
 (let ((?x157 (- other_rate_changed (* (* other_granularity_changed ?x64) slope))))
 (let ((?x159 (ite (< ?x157 lower) lower ?x157)))
 (let (($x154 (= other_rate_changed 0.0)))
 (= next_b_again (ite $x154 0.0 (ite (> ?x159 upper) upper ?x159)))))))))))
(assert
 (let (($x164 (= next_a next_a_again)))
(not $x164)))
(check-sat)
