(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun first () Real)
(declare-fun last () Real)
(declare-fun total () Real)
(declare-fun n () Real)
(declare-fun slope () Real)
(assert
 (>= first 0.0))
(assert
 (>= last 0.0))
(assert
 (> total 0.0))
(assert
 (>= total (+ first last)))
(assert
 (>= n 2.0))
(assert
 (= (* slope total) (* n (- last first))))
(assert
 (let (($x27 (<= slope n)))
(let (($x26 (>= slope (- n))))
(let (($x28 (and $x26 $x27)))
(not $x28)))))
(check-sat)
