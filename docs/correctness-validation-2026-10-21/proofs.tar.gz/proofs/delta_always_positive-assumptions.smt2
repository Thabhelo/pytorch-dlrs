(set-option :timeout 5000)
(set-logic QF_NRA)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun delta_d () Real)
(declare-fun delta_o () Real)
(declare-fun delta_i () Real)
(assert
 (> delta_d 0.0))
(assert
 (> delta_o 0.0))
(assert
 (> delta_i 0.0))
(check-sat)
