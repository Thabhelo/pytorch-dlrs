
import hashlib
import json
import os
import platform
import sys
from pathlib import Path

import pytest

DATA = {"schema_version": 1, "collected": [], "collection_errors": [],
        "internal_errors": [], "reports": [], "test_sources": {}}

def identity(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

def source_identity():
    import dlrs
    import dlrs.scheduler
    import dlrs.utils
    return {"dlrs/__init__.py": identity(dlrs.__file__),
            "dlrs/scheduler.py": identity(dlrs.scheduler.__file__),
            "dlrs/utils.py": identity(dlrs.utils.__file__)}

def pytest_sessionstart(session):
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    DATA["environment"] = {"python": platform.python_version(),
        "executable": sys.executable, "platform": platform.platform(),
        "torch": str(torch.__version__), "pytest": pytest.__version__,
        "torch_threads": torch.get_num_threads(),
        "torch_interop_threads": torch.get_num_interop_threads()}
    DATA["source_before"] = source_identity()

def pytest_collection_finish(session):
    DATA["collected"] = [item.nodeid for item in session.items]
    for item in session.items:
        DATA["test_sources"][item.path.relative_to(session.config.rootpath).as_posix()] = identity(item.path)

def pytest_collectreport(report):
    if report.failed:
        DATA["collection_errors"].append(str(report.longrepr))

def pytest_internalerror(excrepr, excinfo):
    DATA["internal_errors"].append(str(excrepr))

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    exc = call.excinfo
    DATA["reports"].append({"nodeid": report.nodeid, "when": report.when,
        "outcome": report.outcome,
        "assertion_failure": bool(exc is not None and issubclass(exc.type, AssertionError)),
        "exception_type": None if exc is None else exc.type.__module__ + "." + exc.type.__name__})

def pytest_sessionfinish(session, exitstatus):
    DATA["exitstatus"] = int(exitstatus)
    DATA["source_after"] = source_identity()
    with open(os.environ["DLRS_MUTATION_REPORT"], "x", encoding="utf-8") as stream:
        json.dump(DATA, stream, indent=2, allow_nan=False)
        stream.write("\n")
